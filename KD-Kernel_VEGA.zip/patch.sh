#!/sbin/sh

dd if=/dev/block/platform/msm_sdcc.1/by-name/boot of=/cache/boot.img
cd /cache
./u boot.img

mv /cache/dt.img /cache/split_img/boot.img-dtb
mv /cache/zImage /cache/split_img/boot.img-dtb

./r
dd if=/cache/image-new.img of=/dev/block/platform/msm_sdcc.1/by-name/boot
rm -rf /cache/*

